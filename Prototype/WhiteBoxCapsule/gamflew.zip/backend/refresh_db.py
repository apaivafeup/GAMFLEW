import clear_db
import schemas_definition
import seed_db


clear_db.main()
schemas_definition.main()
seed_db.main()