export class CodeFile {
  constructor(id, name, content) {
    this.id = id
    this.name = name
    this.content = content
  }
}
