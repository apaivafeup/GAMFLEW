export class BoardState {
    constructor(id, name, board_state, out_of_bounds_state) {
      this.id = id
      this.name = name
      this.board_state = board_state
      this.out_of_bounds_state = out_of_bounds_state
    }
  }
  