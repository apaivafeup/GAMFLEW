# import db_op
import schemas_definition
import seed_db

# db_op.main()
schemas_definition.main()
seed_db.main()